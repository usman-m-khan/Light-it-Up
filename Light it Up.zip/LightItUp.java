// LightItUp.java
// Usman Khan
// I created light it up, it is a game where the player is trying to jump on each shape, which will light it up, while doing this
// they will try to collect as many stars as possible. If the player falls past the lowest shape he loses

// This file is used to intertwine all classes, draw menu screens run the intro, open scores file. and update and change the game mode.

import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Random;
import java.util.Scanner;

import javax.swing.*;
import java.awt.MouseInfo;
import java.awt.MouseInfo;

public class LightItUp extends JFrame {

	public LightItUp() {
		super("LightItUp");//shows title in the frame
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//closes on exit

		LightItUpPanel game = new LightItUpPanel();//creates a new panel in the frame
		add(game);//adds panel to the frame
		pack();
		// setResizable(false);
		setVisible(true);
	}

	public static void main(String[] arguments) {
		LightItUp frame = new LightItUp();
	}
}

class LightItUpPanel extends JPanel implements KeyListener, ActionListener, MouseListener {
	private boolean[] keys;
	private Timer myTimer;
	private String mode = "menu";
	private Font fnt;
	private Player player; //player class
	private Shapes shapes; //shapes class
	private Stars stars; //stars class

	//Images for the game and menu
	private Image background;
	private Image menuButtonImage;
	private Image fallen;
	private Image starCount;
	private Image startImage;
	private Image startImageDown;
	private Image starCountDown;

	private Map map; //Used to access data about the map

	//Used for the intro at the start
	private String introDirection = "forward"; //moving anim forward or back
	private int introInd = 0;

	private int level = 1;//current level
	private int dx, dy; //dimensions of game


	//button in the menu and end screen
	private Rectangle menuButton;
	private Rectangle restartButton;
	private Rectangle continueButton;
	private Rectangle startButton;
	private Rectangle recordButton;

	private int starsCollected;//collected in level
	private int totCollected;// total stars collected in your run
	private int score; //You dont see this, just used for records placement

	private String []allScores; //used to store record data

	public LightItUpPanel() {
		keys = new boolean[KeyEvent.KEY_LAST + 1];
		myTimer = new Timer(50, this);
		fnt = new Font("Comic Sans", Font.BOLD, 15);

		//boundries
		dx = 1000;
		dy = 800;

		//loading images
		background = load("images/background.jpg");
		menuButtonImage = load("images/menuButton.png");
		fallen = load("images/fallen.png");
		starCount = load("images/starCount.png");
		startImage = load("images/startButton.png");
		startImageDown = load("images/startButtonDown.png");
		starCountDown= load("images/starCountDown.png");

		//setting the buttons 
		menuButton = new Rectangle(20, 20, 50, 50);
		restartButton = new Rectangle(dx / 2 - 100, dy / 2 + 105, 200, 50);
		continueButton = new Rectangle(dx / 2 - 100, dy / 2 + 105, 200, 50);
		startButton = new Rectangle(700,500, startImageDown.getWidth(null), startImageDown.getHeight(null));
		recordButton = new Rectangle(200,300,starCount.getWidth(null),starCount.getHeight(null));

		//starting the level
		player = new Player(150, 500); //player start coord
		shapes = new Shapes();
		shapes.generate(); //generates the level
		stars = new Stars(shapes.getShapes(), player.getRect());
		map = new Map(shapes.getShapes()); //gets data of map
		stars.generate(map.getFarthest()); //generates stars

		//used to calc score
		score = 0;
		starsCollected=0;
		totCollected=0;

		allScores = new String[10]; //top ten scores

		setPreferredSize(new Dimension(dx, dy));
		addKeyListener(this); //key inputs
		addMouseListener(this); // mouse inputs

		getScores(); //opens file of scores
	}

	public Image load(String name) { //loads images
		return new ImageIcon(name).getImage();
	}

	private Color randomColors() { //creates a random color
		Random rand = new Random();

		int r = rand.nextInt(256);
		int g = rand.nextInt(256);
		int b = rand.nextInt(256);

		return new Color(r,g,b);
	}


	// addNotify triggers when the Panel gets added to the frame.
	// Using this avoids null-pointer exceptions.
	// x.y() - if x is null, we get null-pointer exception
	@Override
	public void addNotify() {
		super.addNotify();
		setFocusable(true);
		requestFocus();
		myTimer.start();
	}

	//Used to collect the records in the score file, and store it in the allScores list
	public  void getScores(){
		try{ //Goes through file scores and adds all the values to the list allscores	
			Scanner inFile = new Scanner(new BufferedReader(new FileReader(new File("scores.txt"))));
			int placement=0;	
			while(inFile.hasNextLine()){
				String name=inFile.nextLine(); //gets the name
				String level=inFile.nextLine(); //gets the level
				String stars=inFile.nextLine(); // gets the score
				inFile.nextLine(); //skips score
				allScores[placement]=name+" Reached level "+level+ " and collected "+stars+" stars"; //adds it to the array list
				placement++;
			}
			inFile.close();
		}
		catch(FileNotFoundException ex){
			System.out.println("Where did you put scores.txt?");
		}
	}

	//Used to display the map during the intro
	private void introAnim(){

		//if the direction is forward the index is added untill all shapes have been displayed
		if (introDirection.equals("forward") && introInd < map.getFarthest() - dx / 2) {
			introInd += 10;
		}
		//if the farthest shape has been displayed
		if (introInd >= map.getFarthest() - dx / 2 && introDirection.equals("forward")) {
			introDirection = "backwards";
		}
		//Goes back to the starting position
		if (introDirection.equals("backwards") && introInd > 0) {
			introInd -= 10;
		}
		//Once complete the game starts
		if (introInd <= 0 && introDirection.equals("backwards")) {
			introDirection = "forward";
			mode = "play";
		}
		//Gives the current direction and everything moves that way, more detail in the comments of the function
		player.playerIntro(introDirection);
		shapes.shapeIntro(introDirection);
		stars.starsIntro(introDirection);
		map.backgroundIntro(introDirection);
	}

	//THis function updates the game, whether they lost or if the mode needs to change
	public void updateGame() {
		//Calls the intro animation if the mode is intro
		if (mode.equals("intro")) {
			introAnim();
		}
		// If the mode is play then functions like movement of player and shapes are called
		if (mode == "play") {
			player.shapes(shapes.getShapes(), shapes.getStand()); //gets info from shapes

			shapes.move(player.getVelX(), player.getVelY(),player.getRect()); //moves the shapes if they are landed on
			player.move(keys); //moves the player

			shapes.lightUp(player.lightUp()); //lights up the shapes if landed

			map.change(shapes.getShapes(), player.getRect()); //updates the farthest points on the map

			stars.change(shapes.getShapes(), player.getRect()); //gets where all the shapes are and the player
			stars.movement(shapes.getMovement()); //if the shapes collide with a star calls this
			stars.checkContact(); //checks if star is collected

			//Moves everything when the player needs to see the other side
			shapes.shapeShift(map.shifting());
			stars.starShift(map.shifting());
			player.playerShift(map.shifting());

			//Checks if the player won or lost and either restarts the game completly or adjustes the score
			if (gameOver().equals("lost")) {
				starsCollected=stars.starsCollected();
				score+=(30*level)+(starsCollected*10);
				mode = "lost";
				restart();
			}
			if (gameOver().equals("winner")) {
				starsCollected=stars.starsCollected();
				score+=(30*level)+(starsCollected*10);
				level++;
				mode = "winner";
				restart();
			}
		}
	}

	//Checks if the player has one or lost
	private String gameOver() {
		//fell past the lowest shape
		if (player.getRect().getY() > map.getLowest() + 300) {
			return "lost";
		}

		//Loops through all the litten shapes, if they all are then winner will be zero and the function will return 0;
		int winner = 0;
		for (boolean lit : shapes.getLitten()) {
			if (lit != true) {
				winner++;
			}
		}
		if (winner == 0) {
			return "winner";
		}
		//if nothing has happened
		return "playing";
	}

	//restarts the game, and creates a new level
	private void restart() {
		//The functionality of all theses functions have been explained above
		shapes = new Shapes();
		shapes.generate();
		stars = new Stars(shapes.getShapes(), player.getRect());
		player = new Player(150, 500);
		map = new Map(shapes.getShapes());
		stars.generate(map.getFarthest());
		totCollected+=starsCollected; //Adds the newly collected stars to the total collected stars
	}

	//used to draw all aspects of the game
	@Override
	public void paint(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;
		map.draw(g, background); //draws the map class, which is just the background
		g.setColor(Color.white);
		fnt = new Font("Comic Sans", Font.BOLD, 15);//Setting font
		g.setFont(fnt);

		//draws the player, shapes and stars during play
		if (mode.equals("play") || mode.equals("start") || mode.equals("intro")) {
			g.drawString("Level " + level, dx / 2, 15); //displays level
			shapes.draw(g);
			player.draw(g);
			stars.draw(g);
		}

		//If the player won all the stars collected are displayed aswell as continue button and menu button
		g.setColor(Color.white);
		if (mode.equals("winner")) {
			fnt = new Font("Comic Sans", Font.BOLD, 40);
			g.setFont(fnt);
			//This just makes it look like the rainbow is displaying "winner"
			String word= "W INNER";
			for(int i=0;i<word.length();i++){
				g.setColor(randomColors());
				g.drawString(""+word.charAt(i), (dx / 2 - 125)+i*40, 100);
			}
			//SHowing all the buttons and writing
			g2d.drawImage(menuButtonImage,20,20,null);
			g2d.draw(continueButton);
			fnt = new Font("Comic Sans", Font.BOLD, 25);
			g.setFont(fnt);
			g.drawString("CONTINUE", (int)restartButton.getX()+35, (int)restartButton.getY()+35);
			for(int i=0;i<starsCollected;i++){
				g.drawImage(starCount,dx/2-175+(125*i),300,null);
			}

		}

		// If the player lost then the fallen stickman is shown and the restart and menu button
		if (mode.equals("lost")) {
			fnt = new Font("Comic Sans", Font.BOLD, 40);
			g.setFont(fnt);
			//rainbow colered letters
			String word= "LOSER";
			for(int i=0;i<word.length();i++){
				g.setColor(randomColors());
				g.drawString(""+word.charAt(i),( dx / 2 - 100)+i*40, 100);
				g.drawImage(fallen,dx/2-100,300,null);
			}
			//displays buttons and text
			g2d.draw(restartButton);
			g2d.drawImage(menuButtonImage,20,20,null);
			fnt = new Font("Comic Sans", Font.BOLD, 25);
			g.setFont(fnt);
			g.drawString("RESTART", (int)restartButton.getX()+40, (int)restartButton.getY()+35);
		}

		//All things needed displayed for the menu
		if (mode.equals("menu")) {
			//title and rainbow theme
			String word= "Light It Up";
			fnt = new Font("Comic Sans", Font.BOLD, 40);
			g.setFont(fnt);
			for(int i=0;i<word.length();i++){
				g.setColor(randomColors());
				g.drawString(""+word.charAt(i), (dx / 2 - 175)+i*30, 100);
			}
			//This makes the buttons grow when hovered overed
			Point mouse = MouseInfo.getPointerInfo().getLocation();
			Point offset = getLocationOnScreen();
			int mx = mouse.x - offset.x;
			int my = mouse.y - offset.y;
			if(startButton.contains(mx,my)){
				g2d.drawImage(startImageDown, 700, 500,null);
			}
			else{
				g2d.drawImage(startImage,700,500,null);
			}
			if(recordButton.contains(mx,my)){
				g2d.drawImage(starCountDown,200, 300,null);
			}
			else{
				g2d.drawImage(starCount,200, 300,null);
			}
		}

		//All things needed displayed for records screen
		if(mode.equals("records")){
			g.drawImage(menuButtonImage,20,20,null); //menu button
			g.setColor(Color.WHITE);
			fnt = new Font("Comic Sans", Font.BOLD, 40);
			g.setFont(fnt);
			g.drawString("Records", 450, 40); //title
			//Shows all records
			fnt = new Font("Comic Sans", Font.BOLD, 20);
			g.setFont(fnt);
			for(int i=0; i<allScores.length;i++){
				g.drawString(allScores[i],100,200+i*30);
			}
		}
	}

	//Checks if mouse is clicked
	@Override
	public void mouseClicked(MouseEvent e) {
		//If any button is pressed in the menu screen it changes the mode to start or records
		if (mode.equals("menu")) {
			if (startButton.contains(e.getPoint())) {
				level = 1;
				score = 0;
				starsCollected=0;
				mode = "start";
			}
			if (recordButton.contains(e.getPoint())) {
				mode = "records";
			}
		}

		//If the game ended the buttons needed are displayed
		if (mode.equals("lost") || mode.equals("winner")) {
			//if the menu button is pressed the game is completly cleared and you are asked for your name for records
			if (menuButton.contains(e.getPoint())) {
				String name = JOptionPane.showInputDialog(String.format("You reached level: %d \nYou collected: %d stars \nName:", level,totCollected)); //takes name from user
				Records.newScore(name,score,level,totCollected);
				getScores();
				level = 1;
				score = 0;
				starsCollected=0;
				totCollected=0;
				name=" ";
				mode = "menu";
			}
		}
		//If you lost and you pressed restart then the game stats are cleared and you restart, name is skaed for records
		if (mode.equals("lost") && restartButton.contains(e.getPoint())) {
			String name = JOptionPane.showInputDialog(String.format("You reached level: %d \nYou collected: %d stars \nName:", level,totCollected)); //takes name from user
			Records.newScore(name,score,level,totCollected);
			getScores();
			level = 1;
			score = 0;
			starsCollected=0;
			totCollected=0;
			name=" ";
			mode = "start";
		}

		//if continure is selected the stats remain the same and you start the next level
		if (mode.equals("winner") && continueButton.contains(e.getPoint())) {
			starsCollected=0;
			mode = "start";
		}

		//If mode is records and you press the menu button
		if(mode.equals("records")){
			if(menuButton.contains(e.getPoint())){
				mode="menu";
			}
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

	// Gets info when mouse is pressed
	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

	@Override
	public void keyPressed(KeyEvent e) {
		//if you press space the intro starts
		keys[e.getKeyCode()] = true;
		if (e.getKeyCode() == KeyEvent.VK_SPACE && mode.equals("start")) {
			mode = "intro";
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		keys[e.getKeyCode()] = false;
	}

	@Override
	public void actionPerformed(ActionEvent evt) {
		updateGame();
		repaint(); // Asks the JVM to indirectly call paint
	}

}
