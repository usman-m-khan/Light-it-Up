// Map.java
// Usman Khan
// This file is used to get the value to adjust everything on the map, get data from the map and draw the background

import java.awt.*;
import java.awt.Color;
import java.awt.Graphics;
import java.util.Arrays;

import javax.swing.ImageIcon;

public class Map {
    private int dimX, dimY;//dimensions of the map

    private int[] shift, del, timer; //Used as timers and delta X and holds shift values for when map moves

    private int left, right, highest, lowest;//holds outer edges of map

    private Shape[] allShapes; //holds all shapes
    private Rectangle player;//holds player rect

    private String[] current;//WHat direction is the map moving in
    private int bx, by;//background coords

    public Map(Shape[] shapes) {
    //Setting initial values of the vars
        dimX = 1000;
        dimY = 800;
        allShapes = shapes;
        left = Integer.MAX_VALUE;
        right = Integer.MIN_VALUE;
        highest = Integer.MAX_VALUE;
        lowest = Integer.MIN_VALUE;
        del = new int[2];
        shift = new int[2];
        current = new String[2];
        timer = new int[2];
        bx = -500;
        by = -500;
    }

    //Updates shapes and player as game progresses
    public void change(Shape[] shapes, Rectangle man) {
        allShapes = shapes;
        player = man;
    }

    //gets the player coords and where they are, if they are at an edge it shifts the screen
    public int[] shifting() {
        getBoundaries();//Updates the boundaries
        //Shifts everything to the right
        if ((player.getCenterX() < 100 || timer[0] < 50) && timer[0] > 0 && !current[0].equals("left")) {
            del[0] = 10;//deltaX is ten
            timer[0]--;//timer goes down for the x timer
            current[0] = "right";//the direction is right
        }
        //Shifts everything left
        if ((player.getCenterX() > dimX - 100 || timer[0] < 50) && timer[0] > 0 && !current[0].equals("right")) {
            del[0] = -10;
            timer[0]--;
            current[0] = "left";
        }

        //Shifts everything down
        if ((player.getCenterY() < 100 || timer[1] < 30) && timer[1] > 0 && !current[1].equals("up")) {
            del[1] = 10;
            timer[1]--;
            current[1] = "down";
        }
        //Shifts everything up
        if ((player.getCenterY() > dimY - 50 || timer[1] < 30) && timer[1] > 0 && !current[1].equals("down")) {
            del[1] = -10;
            timer[1]--;
            current[1] = "up";
        }
        //Adds delta x to the shift value
        shift[0] += del[0];
        shift[1] += del[1];

        //resets x and y timers when there emptied
        if (timer[0] <= 0) {
            timer[0] = 50;
            del[0] = 0;
            current[0] = "none";
        }
        if (timer[1] <= 0) {
            timer[1] = 30;
            del[1] = 0;
            current[1] = "none";
        }
        return shift;//return the shift values
    }

    //returns the direction the map is moving in
    public String[] getCurrent() {
        return current;
    }

    //gets the boundaries of the map
    private void getBoundaries() {
        // if the coord value is greater or lesser than the prev boundrary value it replaces the old one wiht th current shapes coord
        for (int i = 0; i < allShapes.length; i++) {
            if (allShapes[i].getBounds().getX() < left) {
                left = (int) allShapes[i].getBounds().getX();
            }
            if (allShapes[i].getBounds().getX() > right) {
                right = (int) allShapes[i].getBounds().getX();
            }
            if (allShapes[i].getBounds().getY() < highest) {
                highest = (int) allShapes[i].getBounds().getY();
            }
            if (allShapes[i].getBounds().getY() > lowest) {
                lowest = (int) allShapes[i].getBounds().getY();
            }
        }
    }

    //Moves the background according to shift
    public void backgroundIntro(String direction) {
        if (direction.equals("forward")) {
            bx-=10;
        }
        if (direction.equals("backwards")) {
            bx+=10;
        }

    }

    //returns the furthest point in the map
    public int getFarthest() {
        getBoundaries();
        return right;
    }

    //returns the lowest point in the map
    public int getLowest() {
        return lowest + shift[1];
    }

    //Draws the background adjusted by shift
    public void draw(Graphics g, Image background) {
        g.drawImage(background,bx+shift[0], by+ shift[1], null);
    }
}
