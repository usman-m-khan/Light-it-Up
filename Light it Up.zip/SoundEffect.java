// SoundEffect.java
// Usman Khan
// This file is used to make the ding sound effect when a shape is litten

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.sound.sampled.Clip;
import javax.sound.sampled.AudioSystem;

public class SoundEffect{
    private Clip c;
    //gets the file name
    public SoundEffect(String filename){
        setClip(filename);
    }
    //opens the file 
    public void setClip(String filename){
        try{
            File f = new File(filename);
            c = AudioSystem.getClip();
            c.open(AudioSystem.getAudioInputStream(f));
        } catch(Exception e){ System.out.println("error"); }
    }
    //plays the sound
    public void play(){
        c.setFramePosition(0);
        c.start();
    }
    //stops the sound
    public void stop(){
        c.stop();
    }
}
