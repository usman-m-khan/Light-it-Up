// Records.java
// Usman Khan
// This file is used to read and change the scores text given

import java.io.*;
import java.util.*;

class Records {
	
	//Loads in the existing score file
	public static void load(ArrayList<String>names,ArrayList<Integer>scores,ArrayList<Integer>levels,ArrayList<Integer>stars){
		//Gets every name and corresponding score,level and stars and adds it to there list
		try{			
			Scanner inFile = new Scanner(new BufferedReader(new FileReader(new File("scores.txt"))));
			while(inFile.hasNextLine()){
				names.add(inFile.nextLine());
				levels.add(Integer.parseInt(inFile.nextLine()));
				stars.add(Integer.parseInt(inFile.nextLine()));
				scores.add(Integer.parseInt(inFile.nextLine()));
			}
			
		}
		catch(FileNotFoundException ex){
			System.out.println("Where did you put scores.txt?");
		}
		
	
	}

	//This saves the new score file
	public static void save(ArrayList<String>names,ArrayList<Integer>scores,ArrayList<Integer>levels,ArrayList<Integer>stars){
		try{
			PrintWriter outFile = new PrintWriter(new BufferedWriter(new FileWriter ("scores.txt")));
			//Inserts the new score,name, level and star if it is top ten
			for(int i=0; i<10; i++){
				outFile.println(names.get(i));
				outFile.println(levels.get(i));
				outFile.println(stars.get(i));
				outFile.println(scores.get(i));
			}
			outFile.close();	
		}
		catch(IOException ex){
			System.out.println(ex);
		}	
	}
	
	//Checks if the new score is a highscore
	public static void highScore(String name, int score,int level,int star){	
		//name,level,star and score lists	
		ArrayList<String>names = new ArrayList<String>();
		ArrayList<Integer>levels = new ArrayList<Integer>();
		ArrayList<Integer>stars = new ArrayList<Integer>();
		ArrayList<Integer>scores = new ArrayList<Integer>();

		load(names, scores,levels,stars); //loading old file

		// Checks if the score is top ten then replaces the old one which was there
		for(int i=0; i<10; i++){
			if(score > scores.get(i)){
				names.add(i,name);
				scores.add(i, score);
				levels.add(i,level);
				stars.add(i,star);
				break;
			}
		}
		save(names,scores,levels,stars); //Saves the new sheet
	}
	
	//Gets the name,level,star and score from user
	public static void newScore(String name,int score,int level,int star){
		highScore(name, score,level,star);
	}
}
