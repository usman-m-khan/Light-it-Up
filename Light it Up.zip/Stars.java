// Stars.java
// Usman Khan
// This file is used to make changes to all stars, check for collision and movement in attraction or push and draw them

import java.awt.*;
import java.util.*;

import javax.swing.ImageIcon;

import java.awt.geom.AffineTransform;

public class Stars {
    private int dimX, dimY; //dimensions of the map
    private Rectangle []stars; //all stars are kept here
    private boolean []collected; //stores if they are collected or not
    private boolean []attracted;// if the star is attracted to the player or not
    private int totCol;// how many have been collected
    private Shape []allShapes; // holds all shapes
    private Rectangle player; //player rect

    private int shiftX,shiftY;//shift to adjust stars when the map shift
    private Image star = new ImageIcon("images/star.png").getImage(); //loads star images

    private SoundEffect sound;//twinkle sound effect

    public Stars(Shape []shapes, Rectangle man){
    //creating all vars and setting there value
        dimX=1000;
        dimY=800;
        totCol=0;
        player=man;
        stars= new Rectangle[3];
        allShapes=shapes;
        collected = new boolean[3];
        attracted = new boolean[3];
        sound = new SoundEffect("sounds/starSound.wav"); //sound effect when new shape is litten
    }

    //updates the the shapes and player vars while the game changes
    public void change(Shape []shapes, Rectangle man){
        allShapes=shapes;
        player=man;
    }

    //generates stars when calles
    public void generate(int farthest){
        Random rand = new Random();
        //Creates three random stars
        for(int i=0; i<stars.length;i++){
            int x = rand.nextInt(farthest-25);//random x between 0 and farthest shape
            int y = rand.nextInt(dimY-50); // top and bottom
            //checks if the star generates inside a shape and adjusts its y coord
            for(Shape j : allShapes){
                if(j.intersects(x,y,20,20)){
                    //moves it up if the shape is in lower half
                    if(j.getBounds().getY()>400){
                        y-=150;
                    }
                    //moves it down if the shape is in the top half
                    else{
                        y+=150;
                    }
                }
                //creates a star and adds it to the star list with the created coords
                stars[i]= new Rectangle(x,y,20,20);
            }
        }
    }

    //moves the stars when a shape pushes them
    public void movement(int [][]movement){
        //goes through all shapes and stars and trasnfer speed when collide is true
        for(int i=0;i<stars.length;i++){
            for(int j=0; j<allShapes.length;j++){
                if(allShapes[j].intersects(stars[i]) && collected[i]!=true){
                    stars[i].translate(movement[j][0],movement[j][1]);
                }
            }
        }
        attraction();
    }

    //Shifts the stars when the map moves
    public void starShift(int[] shifting){
        //substracts the prev shift val by the new and translates all the stars by the diffrence
        int x=shifting[0]-shiftX;
        int y=shifting[1]-shiftY;
        shiftX=shifting[0];
        shiftY=shifting[1];
        //Moves the stars
        for(int i=0;i<stars.length;i++){
            if(collected[i]==false){
                stars[i].translate(x, y);
            }
        }
        
    }

    //The attraction betwwen the player and star
    private void attraction(){
        for(int i=0;i<stars.length;i++){
            //If the star is not already collected or the attraction has begun already the the star moves towrds the player
            if(collected[i]!=true && (getDist(player.getCenterX(), player.getCenterY(), stars[i].getCenterX(), stars[i].getCenterY())<100 || attracted[i]==true)){
                attracted[i]=true;//the attraction has begun and will not stop untill it is collected
                //Calculates the angle needed to move in
                double deltaX = player.getCenterX() - stars[i].getCenterX();
                double deltaY = player.getCenterY() - stars[i].getCenterY();
                double angle = Math.atan2( deltaY, deltaX );
                //moves the star there
                stars[i].translate((int)(25 * Math.cos( angle )),(int)(25 * Math.sin( angle )));
            }
        }
    }

    //Checks contact between player and star
    public void checkContact(){
        //if they are in contact the it is displayed in the top left and collected is true
        for(int i=0; i<stars.length;i++){
            if(player.intersects(stars[i]) && collected[i]!=true){
                totCol++;
                stars[i]= new Rectangle(25*totCol-15,10,20,20);
                collected[i]=true;
                sound.play();//plays twinkle sound
            }
        }
    }

    //This is used to move the stars during the intro
    public void starsIntro(String direction){
        for(Rectangle i:stars){
            if (direction.equals("forward")){
                i.translate(-10,0);
            }
            if (direction.equals("backwards")){
                i.translate(10,0);
            }
        }
    }

    //returns the dist between the player and star
    private double getDist(double x1,double y1,double x2,double y2){
        return Math.hypot(x1-x2, y1-y2);
    }

    //Returns how many stars have been collected during the level
    public int starsCollected(){
        int count=0;
        for(int i=0;i<collected.length;i++){//goes through list if true the count is increased
            if (collected[i]==true){
                count++;
            }
        }
        return count;
    }

    //Draws all aspects of star
    public void draw(Graphics g){
        Graphics2D g2d = (Graphics2D) g;
        //Draws all stars in image form
        for(Rectangle i:stars){
            g2d.drawImage(star, (int)i.getX(),(int)i.getY(), null);
        }
    }
}

