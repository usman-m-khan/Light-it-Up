// Player.java
// Usman Khan
// This file is used to make changes to the player, move them based off keys and gravity, slow them down when landing, and draw the player

import java.awt.*;
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.*;

public class Player {
    private int x, y, velX, velY, acX, acY; //world coordinates of player acceleration and velocity
    private int dimX, dimY; //dimensions of the map
    private int prevDir; //the direction the player is in
    private int jumpLim; //the jump limit is two
    private final int gravity = 1;// pulls player down while jumping

    private boolean landed;// did the player land
    private int keyPressed; //checks if a key was pressed makes sure two arent pressed at a time
    private boolean jumping;// is the player jumping
    
    private Rectangle player;// rectangle of player

    private Shape[] shapes; //All shapes
    private boolean[] standing; //what shape the player is standing on

    //All images
    private Image stance;
    private Image[] jumpingImages;
    private int jumpingInd;

    //Shifts the world coordinates to a certain direction depending on where the player moved
    private int shiftX;
    private int shiftY;

    public Player(int xx, int yy) {
        //Setting the values to what is needed
        x = xx;
        y = yy;
        prevDir = 0; // zero is left 1 is right
        jumpLim = 2;
        keyPressed = 0;
        jumpingInd = 0;
        landed = false;
        jumping = false;
        dimX=1000;
        dimY=800;
        player = new Rectangle(x, y, 20, 30);
        jumpingImages = new Image[4];

        //loading the images
        stance = load("images/stance.png");
        for (int i = 0; i < jumpingImages.length; i++) {
            jumpingImages[i] = load("images/jumping" + i + ".png");
        }
    }

    //This function makes sure the user releases the key the has to press again to jump
    private void keySet(boolean[] keys) {
        //if a key is pressed keypressed increases 
        if (keys[39] || keys[37] && keyPressed < 2) {
            keyPressed += 1;
        }
        //once complatly released it returns to zero
        if (keys[39] == false && keys[37] == false && keyPressed > 0) {
            keyPressed = 0;
        }
    }

    public void move(boolean[] keys) {
        keySet(keys);

        //If the key is pressed the player jumps to the left
        if (keyPressed == 1 && keys[37] && jumpLim > 0) {
            jumpLim--; //substracts from jump lim
            jumping = true;//player is jumping

            //acceleration adjusts
            acX = -2;
            acY = -5;

            prevDir = 0; //direction

        }
        //player jumps right
        if (keyPressed == 1 && keys[39] && jumpLim > 0) {
            jumpLim--;
            jumping = true;
            acX = 2;
            acY = -5;
            prevDir = 1;
        }
        jump();// moves the player
    }

//This moves the player based on what the state is
    private void jump() {

        //If the player is not on a shape gravity is added
        if (landed == false) {
            velY += gravity;
        }
        //If the player is jumping they accelerate in the upwards dierction
        if (jumping == true) {
            velY += acY; //adding to vel
        }
        //Acceleration stops adding once the player reaches a vel of -15 upwards
        if (velY < -15) {
            jumping = false;
        }
        //moves the player to the right depending on direction at a vel of 5 pixels
        if ((acX < 0 ? velX > -5 : velX < 5) && landed == false) {
            velX += acX;
        }
        //Adding vel to player
        x += velX;
        y += velY;

        player = new Rectangle(x+shiftX, y+shiftY, 20, 30); //creating player rect

        landed = landing();// cheks if player has landed

        //If it is true,the player slows down
        if (landed == true) {
            //Makes it so the player remains in the angle it was traveleing in before they landed
            double deltaX = player.getCenterX()+velX - player.getCenterX();
            double deltaY = player.getCenterY()+velY - player.getCenterY();
            double angle = Math.atan2( deltaY, deltaX ); //getting the angle
            //Slowing down the player by the value inclduing the angle
            if(velX!=0){
                velX-=(int)(2 * Math.cos( angle ));
            }
            if(velY!=0){
                velY-=(int)(2 * Math.sin( angle ));
            }
            jumpLim = 2;//rests the jump lim
        }
    }

    //Gets shaoes data
    public void shapes(Shape[] allShapes, boolean[] stand) {
        shapes = allShapes; //the shape list
        standing = stand;//what shape he is standing on
    }

    //Checks if the player has landed
    private boolean landing() {
        //If the player is standing on the shape, and jumps through it makes landed false and allows it
        for (int i = 0; i < shapes.length; i++) {
            if (standing[i] == true && (jumping == true || landed == false)) {
                return false;
            }
            //if the player is on the shape the landed is true
            if (shapes[i].intersects(player.getX(), player.getY(), player.getWidth(), player.getHeight())) {
                return true;
            }
        }
        return false;
    }

    //This function checks if the player is standing on the shape and return the index, which is udes later to light up the shape
    public int lightUp() {
        for (int i = 0; i < shapes.length; i++) {
            if (shapes[i].intersects(player.getX(), player.getY(), player.getWidth(), player.getHeight())) {
                return i;
            }
        }
        return -1; //returns -1 if player is on nothing
    }

    //gets the shift numbers needed to orient the player
    public void playerShift(int []shifting){
        shiftX=shifting[0];
        shiftY=shifting[1];
    }

    //This is used in the intro to keep the player to the left
    public void playerIntro(String direction) {
        //if forward the player moves left
        if (direction.equals("forward")) {
            player.translate(-10, 0);
        }
        //if backwards it moves right
        if (direction.equals("backwards")) {
            player.translate(10, 0);
        }
    }

//Returning the velocity and the rectangle of the player
    public int getVelX() {
        return velX;
    }
    public int getVelY() {
        return velY;
    }
    public Rectangle getRect() {
        return player;
    }

    //Loads the images
    private Image load(String name) {
        return new ImageIcon(name).getImage();
    }

    //draws the aspects of the player
    public void draw(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.GREEN);
        
        //The jumping images are run through when jumping is true
        if (jumping == true) {
            //prevDir is used to see what direction the player is in and orrients the images accordingly
            if (prevDir==1) {
                g2d.drawImage(jumpingImages[jumpingInd], (int) player.getX(), (int) player.getY(), null);
                jumpingInd++;
            }
            if (prevDir==0) {
                g2d.drawImage(jumpingImages[jumpingInd], (int) player.getX() + jumpingImages[jumpingInd].getWidth(null),(int) player.getY(), -jumpingImages[jumpingInd].getWidth(null), jumpingImages[jumpingInd].getHeight(null), null);
                jumpingInd++;
            }
            //Jumping Ind is used as the index to get the picture, once it reaches four it resets
            if(jumpingInd==4){
                jumpingInd=0;
            }

        }

        //WHen the player is falling
        if (jumping == false && landed == false) {

            //Intro circle
            if(acX==0){
                g.setColor(Color.WHITE);
                g.fillOval((int)player.getX(),(int) player.getY(), 15, 15);
            }

            //Displays the falling image oriented according to direction
            if (prevDir==1 && acX!=0) {
                g2d.drawImage(jumpingImages[3], (int) player.getX(), (int) player.getY(), null);
            }
            if (prevDir==0 && acX!=0) {
                g2d.drawImage(jumpingImages[3], (int) player.getX() + jumpingImages[3].getWidth(null),(int) player.getY(), -jumpingImages[3].getWidth(null), jumpingImages[3].getHeight(null), null);
            }
        }

        //Shows the stance image oriented according to direction
        if (landed == true && prevDir == 1) {
            g.drawImage(stance, (int) player.getX(), (int) player.getY(), null);
        }
        if (landed == true && prevDir == 0) {
            g2d.drawImage(stance, (int) player.getX() + stance.getWidth(null), (int) player.getY(),-stance.getWidth(null), stance.getHeight(null), null);
        }
    }
}
