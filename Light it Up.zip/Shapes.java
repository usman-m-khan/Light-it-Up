// Shapes.java
// Usman Khan
// This file is used to generate shapes, make changes to there location, check contact and light shapes, check the amount they need to move by
// when the player pushes them, and draws all shapes based on litten or not

import java.awt.*;
import java.util.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.AffineTransform;

public class Shapes {
    private int dimX, dimY;// Dimensions of screen

//THese are the arrayswhich hold the Shape collor and whether it was litten
    private Shape[] allShapes;
    private Color[] allColors;
    private boolean[] litten;

    //checks if the player was stading contact checks for immediate contact
    private boolean[] standing;
    private int[] contact;

    private double[] angles; //angle to turn shape when landed on
    private int[][] movement; //When landed the X and Y push
    private int shiftX,shiftY; //Used to orient the shapes when the map moves
    private SoundEffect sound; //sounds effect

    public Shapes() {

//Setting the starting values and callling what is needed
        dimX=1000;
        dimY=800;

        //Random length of shapes needed to be created
        Random rand = new Random();
        allShapes = new Shape[rand.nextInt((10 + 1) - 7) + 7];

        //All parralel lists are the same length
        allColors = new Color[allShapes.length];
        litten = new boolean[allShapes.length];
        standing = new boolean[allShapes.length];
        contact = new int[allShapes.length];
        movement = new int[allShapes.length][2];
        angles = new double[allShapes.length];

        sound = new SoundEffect("sounds/lit.wav"); //sound effect when new shape is litten

    }


    //This function generates new shapes and coordinates when called
    public void generate() {
        //Creates random shapes either, Circle, rectangle or Triangle
        Random rand = new Random();
        //Keeps creating shapes for length of allShapes
        for (int i = 0; i < allShapes.length; i++) {
            int shape = rand.nextInt(3); // 0-rect, 1,ellipse, 2-Tri

            if (shape == 0) {
                //rectangle
                int x;
                int y;
                //random size
                int w = rand.nextInt((100 + 1) - 50) + 50;
                int h = rand.nextInt((100 + 1) - 50) + 50;
                
                //If it is the first shape the the x and y are decided
                if (i == 0) {
                    x = 150;
                    y = 300;
                } 
                //Random y coords set x dist
                else {
                    x = (int) allShapes[i - 1].getBounds().getCenterX() + (int) allShapes[i - 1].getBounds().getWidth();//Must be a certain dist away from prev shape
                    y = rand.nextInt(dimY-50);//random y coord
                }
                allShapes[i] = generateRect(x, y, w, h);//creates a new rect and adds it to all shapes
            }

            if (shape == 1) {
                //Ellipse
                double x;
                double y;
                Double r = (double) rand.nextInt((100 + 1) - 50) + 50;//random size
                //If first shape
                if (i == 0) {
                    x = 150;
                    y = 300;
                } 
                //Random height set x coord
                else {
                    x = allShapes[i - 1].getBounds().getCenterX() + allShapes[i - 1].getBounds().getWidth();
                    y = rand.nextInt(dimY-50);
                }
                allShapes[i] = generateEllipse(x, y, r, r); //generates the new ellipse and adds it to allShapes
            }

            if (shape == 2) {
                //triangle
                int x;
                int y;
                int w = rand.nextInt((100 + 1) - 50) + 50; //random size

                //All coords in a list to create polygon
                int[] xcoor = new int[3];
                int[] ycoor = new int[3];

                //If it is the first shape
                if (i == 0) {
                    x = 150;
                    y = 300;
                } 
                //Random y set x
                else {
                    x = (int) allShapes[i - 1].getBounds().getCenterX() + (int) allShapes[i - 1].getBounds().getWidth()
                            + w;
                    y = rand.nextInt(dimY-50);
                }
                //Creating the polygon using the coords to add to the lists
                xcoor[0] = x - w;
                xcoor[1] = x;
                xcoor[2] = x + w;
                ycoor[0] = y + w;
                ycoor[1] = y;
                ycoor[2] = y + w;
                allShapes[i] = generateTriangle(xcoor, ycoor, 3); //generates polygon and adds to allSHapes
            }
        }
        randomColors();//sets a randmo color for the all shapes
    }

    //sets a random color in the allcolors list
    private void randomColors() {
        Random rand = new Random();
        for (int i = 0; i < allColors.length; i++) {
            int r = rand.nextInt(256);
            int g = rand.nextInt(256);
            int b = rand.nextInt(256);
            allColors[i] = new Color(r, g, b);
        }
    }

    //takes the given coords and returns a new rect
    private Rectangle generateRect(int x, int y, int w, int h) {
        Rectangle newRect = new Rectangle(x, y, w, h);
        return newRect;
    }

    //takes the given coords and returns a new ellipse
    private Ellipse2D generateEllipse(double x, double y, double w, double h) {
        Ellipse2D.Double newEllipse = new Ellipse2D.Double(x, y, w, h);
        return newEllipse;
    }

    //takes the given coords and returns a new triangle
    private Polygon generateTriangle(int[] xpoints, int[] ypoints, int npoints) {
        Polygon newTri = new Polygon(xpoints, ypoints, npoints);
        return newTri;
    }

//These are used to access data from this class, all the shapes, there speed, is there stood on, if litten
    public Shape[] getShapes() {
        return allShapes;
    }
    public int [][] getMovement() {
        return movement;
    }
    public boolean[] getStand() {
        return standing;
    }
    public boolean[] getLitten(){
        return litten;
    }

    //Gets the index from the player and checks if the current stood on shape is litten
    public void lightUp(int ind) {
        //If it is not litten it turns litten to true and plays the sound
        if (ind != -1 && litten[ind]!=true) {
            litten[ind] = true;
            sound.play();
        }
        //adjust the standing list if the index matches the shape
        for (int i = 0; i < standing.length; i++) {
            if (ind == i) {
                standing[i] = true;
            } else {
                standing[i] = false;
            }
        }

    }

    //Checks if the player has contacted the shape for one frame
    private void allContacts() {
        //if standing is true and contact has not been accounted for it changes it and breaks
        for (int i = 0; i < standing.length; i++) {
            //Checks first frame contact tand breaks loop if true
            if (contact[i] == 0 && standing[i] == true) {
                contact[i] = 1;
                break;
            }
            //next frame it will turn the value to two if they are still standing
            if (contact[i] == 1 && standing[i] == true) {
                contact[i] = 2;
            }
            //resets contact once the player leaves
            if (standing[i] == false) {
                contact[i] = 0;
            }
        }
    }

    public void move(int velX, int velY,Rectangle player) {
        allContacts(); //calls contact
        //transfers player vel to the shape
        for (int i = 0; i < contact.length; i++) {
            if (contact[i] == 1) {//only transfers on initial contact
                movement[i][0] = velX;
                movement[i][1] = velY;

                //setting angle of dip
                if(velX!=0 && velY!=0){
                    angle(velX,velY,player,i);//gives all neede data
                }
            }
        }
        movement();//moves the shape
    }

    //sets the angle when landed on
    private void angle(int velX,int velY,Rectangle player,int ind){
        //getting the x and y dists from the center on the shape
        double deltaX = (allShapes[ind].getBounds().getCenterX()-player.getCenterX());
        double deltaY = (allShapes[ind].getBounds().getCenterY()-player.getCenterY());

        //This rotates the shape based on where is lands then adds the angle to the angle class
        if(deltaY>10 && deltaX>10){
           angles[ind] = -1*Math.abs(atan2( deltaY, deltaX )/5);
        }
        if(deltaY>10 && deltaX<-10){
            angles[ind] = Math.abs(atan2( deltaY, deltaX)/5);
         }
         if(deltaY<-10 && deltaX>10){
            angles[ind] = Math.abs(atan2( deltaY, deltaX )/5);
         }
         if(deltaY<-10 && deltaX<-10){
            angles[ind] = -1*Math.abs(atan2( deltaY, deltaX )/5);
         }
    }

    //sets it so the coords are like real life
    private double atan2(double y, double x){
        return Math.atan2(dimY-y,x);
    }


    //This function moves the shapes
    private void movement() {
        for (int i = 0; i < movement.length; i++) {

            //Sets the amount needed to move and rotate in the affine transform tx
                AffineTransform tx = new AffineTransform();
                tx.translate(movement[i][0], movement[i][1]);
                tx.rotate(angles[i],allShapes[i].getBounds().getCenterX(),allShapes[i].getBounds().getCenterY());
                allShapes[i] = tx.createTransformedShape(allShapes[i]);// moves the shapes

                //The angle that is needed to move the shape in the right direction
                double deltaX = allShapes[i].getBounds().getCenterX()+movement[i][0] - allShapes[i].getBounds().getCenterX();
                double deltaY = allShapes[i].getBounds().getCenterY()+movement[i][1] - allShapes[i].getBounds().getCenterY();
                double angle = Math.atan2( deltaY, deltaX );

                //This slows down the shape in the right angle
                if (movement[i][0] != 0) {
                    movement[i][0]-=(int)(2 * Math.cos( angle ));
                }
                if (movement[i][1] != 0) {
                    movement[i][1]-=(int)(2 * Math.sin( angle ));
                }
                //If the shape is stuck at one it moves it to one
                if(Math.abs(movement[i][0])<=1){
                    movement[i][0]=0;
                }
                if(Math.abs(movement[i][1])<=1){
                    movement[i][1]=0;
                }
            
            //If the shape is stuck at .1 it makes it 0
            if(Math.abs(angles[i])<=.1){
                angles[i]=0;
            }
            //slowly reduces the angle untill it hits 0
            if(angles[i]!=0){
                angles[i]= angles[i]+(angles[i]>0 ? -.1 :.1);
            }

            //This checks if two shapes collided and transfers the velocity to the next shape
            for (int j = 0; j < movement.length; j++) {
                if (allShapes[i].intersects(allShapes[j].getBounds()) && i != j) {
                    if (movement[i][0] != 0 && Math.abs(movement[i][0]-movement[j][0])!=1) {
                        movement[j][0] = movement[i][0]+(movement[i][0]>0 ? 1 : -1);
                        movement[i][0] = movement[i][0]+(movement[i][0]>0 ? -1 : 1);
                    }
                    if (movement[i][0] != 0 && Math.abs(movement[i][0]-movement[j][0])!=1) {
                        movement[j][1] = movement[i][1]+(movement[i][1]>0 ? 1 : -1);
                        movement[i][1] = movement[i][1]+(movement[i][1]>0 ? -1 : 1);
                    }
                    //If they collide they both are litten
                    litten[i] = true;
                    litten[j] = true;
                }
            }
        }
    }

    //Orrients the shape when the map shifts
    public void shapeShift(int[]shifting){
        //Gets previous shift number and substracts the new one from it, then transforms all shapes by the diffrence
        int x=shifting[0]-shiftX;
        int y=shifting[1]-shiftY;
        shiftX=shifting[0];
        shiftY=shifting[1];

        //shifting the shapes
        for(int i =0;i<allShapes.length;i++){
            AffineTransform tx = new AffineTransform();
            tx.translate(x, y);
            allShapes[i] = tx.createTransformedShape(allShapes[i]);
        }
        
    }

    //The animation for the shapes during the intro
    public void shapeIntro(String direction){
        for(int i=0;i<allShapes.length;i++){
            //if Forward then all shapes move left
            if(direction.equals("forward")){
                AffineTransform tx = new AffineTransform();
                tx.translate(-10, 0);
                allShapes[i] = tx.createTransformedShape(allShapes[i]);
            }
            //when backwards all shapes move right
            if(direction.equals("backwards")){
                AffineTransform tx = new AffineTransform();
                tx.translate(10, 0);
                allShapes[i] = tx.createTransformedShape(allShapes[i]);
            }
        }
    }

    //used to draw all aspects of the shape
    public void draw(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        //Draws all the shapes , with there color and fills them if there litten
        for (int i = 0; i < allShapes.length; i++) {
            g2d.setColor(allColors[i]);
            if (litten[i] == false) {
                g2d.draw(allShapes[i]);
            } else {
                g2d.fill(allShapes[i]);
            }
        }
    }

}
